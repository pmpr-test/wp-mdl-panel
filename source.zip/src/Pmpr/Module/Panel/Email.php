<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a63d55cdb36             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Mailer\AbstractEmail; class Email extends AbstractEmail { public function qiccuiwooiquycsg() { $this->usuqmwksoeaayaig('forgot_password')->gswweykyogmsyawy(__('Panel Forgot Password', PR__MDL__PANEL))->gucwmccyimoagwcm(__('Configure Forgot Password', PR__MDL__PANEL))->saemoowcasogykak(IconInterface::cokkqwmiaowmqcqs); } }

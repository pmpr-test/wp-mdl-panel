<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec240d1a8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin; use Pmpr\Module\Panel\Container; class Common extends Container { }

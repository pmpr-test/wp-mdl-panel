<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7b5e6c22             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\157\x63\x6f\x6d\155\x65\162\143\145\137\x72\145\163\x74\137\143\150\x65\143\x6b\137\x70\145\x72\155\x69\163\x73\151\x6f\156\163", [$this, "\153\x6f\145\151\x6d\x77\x65\143\x79\x69\x69\161\x67\145\163\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\x67\145\x74\x5f\x6a\167\x74\x5f\141\x75\164\150\x5f\164\x6f\153\145\156", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto csscmcacoikwsecs; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto asmecuqiyyswueqe; } $qoowakyqgwcscuss = true; asmecuqiyyswueqe: csscmcacoikwsecs: return $qoowakyqgwcscuss; } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052a8f95521             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x6f\x6f\x63\157\155\x6d\x65\x72\143\x65\x5f\x72\x65\x73\164\137\x63\150\x65\143\153\137\160\x65\162\x6d\151\163\x73\151\157\156\x73", [$this, "\153\x6f\x65\x69\155\x77\145\143\x79\x69\151\161\147\145\x73\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\x67\145\x74\x5f\152\x77\x74\x5f\141\x75\164\150\137\164\x6f\x6b\x65\156", false); if ($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac)) { $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if ($mkucggyaiaukqoce) { $qoowakyqgwcscuss = true; } } return $qoowakyqgwcscuss; } }

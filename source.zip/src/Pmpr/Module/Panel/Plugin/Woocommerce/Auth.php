<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051783c06fb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\157\x6f\143\157\155\x6d\145\162\x63\145\x5f\x72\x65\163\164\x5f\x63\x68\145\143\153\x5f\160\x65\162\155\151\x73\163\x69\x6f\156\163", [$this, "\x6b\x6f\x65\151\155\x77\x65\143\171\x69\151\161\147\145\163\x6b"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\x67\x65\164\137\x6a\167\164\x5f\x61\165\164\150\137\164\x6f\153\x65\x6e", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto mugqyyeayeyggqqk; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto ouamogymawucwswu; } $qoowakyqgwcscuss = true; ouamogymawucwswu: mugqyyeayeyggqqk: return $qoowakyqgwcscuss; } }

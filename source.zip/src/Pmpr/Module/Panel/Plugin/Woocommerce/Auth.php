<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec240d1a8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x6f\157\143\157\x6d\x6d\x65\162\x63\x65\137\x72\x65\163\x74\x5f\143\150\x65\143\153\x5f\x70\x65\x72\155\151\x73\163\x69\157\156\163", [$this, "\x6b\x6f\145\151\x6d\167\145\x63\x79\x69\151\x71\147\x65\163\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\x67\x65\x74\137\x6a\x77\x74\x5f\141\x75\x74\150\137\164\x6f\x6b\145\x6e", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto csscmcacoikwsecs; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto asmecuqiyyswueqe; } $qoowakyqgwcscuss = true; asmecuqiyyswueqe: csscmcacoikwsecs: return $qoowakyqgwcscuss; } }

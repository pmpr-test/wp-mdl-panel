<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67803815d22b5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; use Pmpr\Module\Panel\Container; class Auth extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\157\x63\157\155\155\145\x72\x63\x65\x5f\162\145\163\164\x5f\143\x68\x65\143\153\x5f\x70\x65\x72\x6d\151\x73\x73\151\157\x6e\163", [$this, "\x6b\157\145\x69\155\167\x65\143\x79\x69\151\161\147\x65\x73\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\145\164\x5f\152\167\x74\137\141\x75\x74\x68\x5f\x74\157\153\x65\156", false); if ($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac)) { $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if ($mkucggyaiaukqoce) { $qoowakyqgwcscuss = true; } } return $qoowakyqgwcscuss; } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a66ef6677fa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel; use Pmpr\Module\Panel\Traits\TokenTrait; class Ajax extends Container { use TokenTrait; public function wigskegsqequoeks() { $this->koaegcswmcqsiykq('panel_get_token', [$this, 'sygeeqgwywmygsyu']); } public function sygeeqgwywmygsyu() { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); if ($ewgmommeawggyaek->ksgkoukcicwkkaum()) { $keccaugmemegoimu = $this->ysyiouymigoigsma($ewgmommeawggyaek->qyeguewwsmosqcwc()); } else { $keccaugmemegoimu = $this->caokeucsksukesyo()->euekiyuksecoccus()->gosmqcmmomkqwmis(__('User is not login.', PR__MDL__PANEL)); } $this->caokeucsksukesyo()->giiecckwoyiawoyy()->uaggqsoeugksgooc($keccaugmemegoimu); } }

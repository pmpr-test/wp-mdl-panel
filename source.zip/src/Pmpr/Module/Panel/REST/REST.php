<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0031cd594             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\REST; use Pmpr\Common\Foundation\REST\RESTRegister; class REST extends RESTRegister { public function gigwcakmiyayoigw() { $this->ogyceaekywowkqsc(Auth::symcgieuakksimmu())->ogyceaekywowkqsc(Router::symcgieuakksimmu())->ogyceaekywowkqsc(Profile::symcgieuakksimmu())->ogyceaekywowkqsc(Setting::symcgieuakksimmu()); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791535e52f05             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\REST; use Pmpr\Common\Foundation\Interfaces\Constants; use WP_Error; use WP_HTTP_Response; use WP_REST_Request; use WP_REST_Response; class Icon extends Common { public function __construct() { $this->rest_base = Constants::qgqyauaqwqmqseim; parent::__construct(); } public function register_routes() { $this->register("\x2f\x73\164\157\x72\145", [Constants::oaggieeykyaoiiyw => self::qucyckeykeuuaquw, Constants::wwgusigoaksqmwsm => [$this, "\141\141\x65\171\145\x63\151\x75\x6f\161\x6f\157\x79\153\153\141"]]); } public function aaeyeciuoqooykka(WP_REST_Request $aqmwamyiwgeeymqa) { $cegeqaoecgsygmiq = $this->aemeowyaecqmymas($aqmwamyiwgeeymqa, Constants::qgqyauaqwqmqseim); $kisaucuwwaaiwuqe = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->eyamqkqiykagecsw($cegeqaoecgsygmiq, [Constants::aisguagukaewucii => Constants::auqoykcmsiauccao]); return $this->ewmkmmsuiuwmmwoy($kisaucuwwaaiwuqe); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679574b2da312             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\REST; use Pmpr\Common\Foundation\Interfaces\Constants; use WP_Error; use WP_HTTP_Response; use WP_REST_Request; use WP_REST_Response; class Icon extends Common { public function __construct() { $this->rest_base = Constants::qgqyauaqwqmqseim; parent::__construct(); } public function register_routes() { $this->register("\57\x73\x74\157\162\x65", [Constants::oaggieeykyaoiiyw => self::qucyckeykeuuaquw, Constants::wwgusigoaksqmwsm => [$this, "\x61\141\145\x79\x65\143\151\x75\157\161\x6f\x6f\171\153\x6b\141"]]); } public function aaeyeciuoqooykka(WP_REST_Request $aqmwamyiwgeeymqa) { $cegeqaoecgsygmiq = $this->aemeowyaecqmymas($aqmwamyiwgeeymqa, Constants::qgqyauaqwqmqseim); $kisaucuwwaaiwuqe = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->eyamqkqiykagecsw($cegeqaoecgsygmiq, [Constants::aisguagukaewucii => Constants::auqoykcmsiauccao]); return $this->ewmkmmsuiuwmmwoy($kisaucuwwaaiwuqe); } }

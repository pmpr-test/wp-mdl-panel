<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678aa11c3f49c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\REST; use Pmpr\Common\Foundation\Interfaces\Constants; use WP_Error; use WP_HTTP_Response; use WP_REST_Request; use WP_REST_Response; class Icon extends Common { public function __construct() { $this->rest_base = Constants::qgqyauaqwqmqseim; parent::__construct(); } public function register_routes() { $this->register("\57\163\x74\157\x72\x65", [Constants::oaggieeykyaoiiyw => self::qucyckeykeuuaquw, Constants::wwgusigoaksqmwsm => [$this, "\x61\141\x65\171\145\143\151\x75\157\x71\x6f\x6f\x79\153\153\x61"]]); } public function aaeyeciuoqooykka(WP_REST_Request $aqmwamyiwgeeymqa) { $cegeqaoecgsygmiq = $this->aemeowyaecqmymas($aqmwamyiwgeeymqa, Constants::qgqyauaqwqmqseim); $kisaucuwwaaiwuqe = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->eyamqkqiykagecsw($cegeqaoecgsygmiq, [Constants::aisguagukaewucii => Constants::auqoykcmsiauccao]); return $this->ewmkmmsuiuwmmwoy($kisaucuwwaaiwuqe); } }
